import { useCart } from "../../shared/context/useCart";

export default function Cart() {
    const { items } = useCart();
    console.log("Cart items:", items);
    

    return (
        <main>
            <h1>Your Cart</h1>

            {items.length === 0 ? (
                <p>Your cart is empty.</p>
            ) : (
                <ul>
                    {items.map((item) => (
                        <li key={item.id}>
                            {item.slug} × {item.quantity}
                        </li>
                    ))}
                </ul>
            )}
        </main>
    );
}