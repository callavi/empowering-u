import "../illustrationAnimations.css";

const RegistrationIllustration = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" {...props}>
    <g id="freepik--background-simple--inject-179">
      <path
        d="M464.86,297.93c-14.73,39.43-44.81,82.11-87.14,94.75-64,19.1-71.6,70.65-186.16,65.87A231.55,231.55,0,0,1,142,451.29a194.41,194.41,0,0,1-23.29-7.75C51.8,416.43,16.89,356.77,14,294.35c-3.82-82.11,53.46-121.24,90.69-144.15S186.79,38.49,299.44,42.31a224.06,224.06,0,0,1,50.92,7.44c37.91,10.26,76.44,33,98.84,66.12q2.52,3.73,4.82,7.64C484,174.36,484.93,244.17,464.86,297.93Z"
        style={{
          fill: "#6D8263",
        }}
      />
      <path
        d="M464.86,297.93c-14.73,39.43-44.81,82.11-87.14,94.75-64,19.1-71.6,70.65-186.16,65.87A231.55,231.55,0,0,1,142,451.29a194.41,194.41,0,0,1-23.29-7.75C51.8,416.43,16.89,356.77,14,294.35c-3.82-82.11,53.46-121.24,90.69-144.15S186.79,38.49,299.44,42.31a224.06,224.06,0,0,1,50.92,7.44c37.91,10.26,76.44,33,98.84,66.12q2.52,3.73,4.82,7.64C484,174.36,484.93,244.17,464.86,297.93Z"
        style={{
          fill: "#fff",
          opacity: 0.7000000000000001,
        }}
      />
      <g
        style={{
          opacity: 0.2,
        }}
      >
        <rect
          x={91}
          y={42}
          width={110.48}
          height={310.86}
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 51.45 201.26 51.45 198.68 42.91"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 61.8 201.26 61.8 198.68 53.26"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 72.15 201.26 72.15 198.68 63.6"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 82.5 201.26 82.5 198.68 73.95"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 92.85 201.26 92.85 198.68 84.3"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 103.2 201.26 103.2 198.68 94.65"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 113.55 201.26 113.55 198.68 105"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 123.9 201.26 123.9 198.68 115.35"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 134.25 201.26 134.25 198.68 125.7"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 144.6 201.26 144.6 198.68 136.05"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 154.95 201.26 154.95 198.68 146.4"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 165.3 201.26 165.3 198.68 156.75"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 175.65 201.26 175.65 198.68 167.1"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 186 201.26 186 198.68 177.45"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 196.34 201.26 196.34 198.68 187.8"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 206.69 201.26 206.69 198.68 198.15"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 217.04 201.26 217.04 198.68 208.5"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 227.39 201.26 227.39 198.68 218.85"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 237.74 201.26 237.74 198.68 229.2"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 248.09 201.26 248.09 198.68 239.55"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 258.44 201.26 258.44 198.68 249.9"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 268.79 201.26 268.79 198.68 260.25"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 279.14 201.26 279.14 198.68 270.59"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 289.49 201.26 289.49 198.68 280.94"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 299.84 201.26 299.84 198.68 291.29"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 310.19 201.26 310.19 198.68 301.64"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 320.54 201.26 320.54 198.68 311.99"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 330.89 201.26 330.89 198.68 322.34"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="91.59 341.24 201.26 341.24 198.68 332.69"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
      </g>
      <g
        style={{
          opacity: 0.2,
        }}
      >
        <rect
          x={209.8}
          y={42}
          width={110.48}
          height={310.86}
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 51.45 320.06 51.45 317.49 42.91"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 61.8 320.06 61.8 317.49 53.26"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 72.15 320.06 72.15 317.49 63.6"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 82.5 320.06 82.5 317.49 73.95"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 92.85 320.06 92.85 317.49 84.3"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 103.2 320.06 103.2 317.49 94.65"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 113.55 320.06 113.55 317.49 105"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 123.9 320.06 123.9 317.49 115.35"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 134.25 320.06 134.25 317.49 125.7"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 144.6 320.06 144.6 317.49 136.05"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 154.95 320.06 154.95 317.49 146.4"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 165.3 320.06 165.3 317.49 156.75"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 175.65 320.06 175.65 317.49 167.1"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 186 320.06 186 317.49 177.45"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 196.34 320.06 196.34 317.49 187.8"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 206.69 320.06 206.69 317.49 198.15"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 217.04 320.06 217.04 317.49 208.5"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 227.39 320.06 227.39 317.49 218.85"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 237.74 320.06 237.74 317.49 229.2"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 248.09 320.06 248.09 317.49 239.55"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 258.44 320.06 258.44 317.49 249.9"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 268.79 320.06 268.79 317.49 260.25"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 279.14 320.06 279.14 317.49 270.59"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 289.49 320.06 289.49 317.49 280.94"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 299.84 320.06 299.84 317.49 291.29"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 310.19 320.06 310.19 317.49 301.64"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 320.54 320.06 320.54 317.49 311.99"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 330.89 320.06 330.89 317.49 322.34"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="210.39 341.24 320.06 341.24 317.49 332.69"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
      </g>
    </g>
    <g id="freepik--Graphics--inject-179">
      <g
        style={{
          opacity: 0.30000000000000004,
        }}
      >
        <rect
          x={23.67}
          y={61.67}
          width={18}
          height={18}
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <rect
          x={23.67}
          y={92.33}
          width={18}
          height={18}
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <line
          x1={48.33}
          y1={71}
          x2={75.67}
          y2={71}
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <line
          x1={48.33}
          y1={101}
          x2={75.67}
          y2={101}
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="27.67 67 30.33 72.33 42.33 54.33"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
      </g>
      <g
        style={{
          opacity: 0.30000000000000004,
        }}
      >
        <rect
          x={289.67}
          y={420.67}
          width={18}
          height={18}
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <rect
          x={289.67}
          y={451.33}
          width={18}
          height={18}
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <line
          x1={314.33}
          y1={430}
          x2={341.67}
          y2={430}
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <line
          x1={314.33}
          y1={460}
          x2={341.67}
          y2={460}
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="293.67 426 296.33 431.33 308.33 413.33"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
      </g>
      <g
        style={{
          opacity: 0.30000000000000004,
        }}
      >
        <rect
          x={350}
          y={52}
          width={18}
          height={18}
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <rect
          x={350}
          y={82.67}
          width={18}
          height={18}
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <line
          x1={374.67}
          y1={61.33}
          x2={402}
          y2={61.33}
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <line
          x1={374.67}
          y1={91.33}
          x2={402}
          y2={91.33}
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
        <polyline
          points="354 57.33 356.67 62.67 368.67 44.67"
          style={{
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeMiterlimit: 10,
          }}
        />
      </g>
    </g>
    <g id="freepik--Floor--inject-179">
      <line
        x1={470.52}
        y1={448.86}
        x2={485.4}
        y2={448.86}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={25}
        y1={448.86}
        x2={463.59}
        y2={448.86}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
    </g>
    <g id="freepik--Plant--inject-179">
      <ellipse
        cx={79.51}
        cy={351.2}
        rx={11.65}
        ry={30.55}
        style={{
          fill: "#6D8263",
          stroke: "#263238",
          strokeMiterlimit: 10,
        }}
      />
      <ellipse
        cx={106.67}
        cy={329.49}
        rx={21.77}
        ry={9.48}
        transform="translate(-239.65 331.38) rotate(-72.37)"
        style={{
          fill: "#6D8263",
          stroke: "#263238",
          strokeMiterlimit: 10,
        }}
      />
      <path
        d="M30.24,401.46c-11.86-2-20.76-7.82-19.88-13s11.19-7.72,23-5.71,20.76,7.82,19.89,13S42.09,403.46,30.24,401.46Z"
        style={{
          fill: "#6D8263",
          stroke: "#263238",
          strokeMiterlimit: 10,
        }}
      />
      <ellipse
        cx={118.46}
        cy={364.94}
        rx={25.25}
        ry={11.65}
        transform="translate(-222.63 189.24) rotate(-44.76)"
        style={{
          fill: "#6D8263",
          stroke: "#263238",
          strokeMiterlimit: 10,
        }}
      />
      <path
        d="M58.43,346.28C68,360.17,70.86,374.82,64.81,379s-18.73-3.71-28.3-17.6-12.43-28.53-6.38-32.71S48.86,332.39,58.43,346.28Z"
        style={{
          fill: "#6D8263",
          stroke: "#263238",
          strokeMiterlimit: 10,
        }}
      />
      <line
        x1={80.33}
        y1={380.22}
        x2={81.23}
        y2={422.22}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeMiterlimit: 10,
        }}
      />
      <line
        x1={79.24}
        y1={339.84}
        x2={80.33}
        y2={380.22}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeMiterlimit: 10,
        }}
      />
      <line
        x1={79.32}
        y1={333.25}
        x2={79.24}
        y2={336.34}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeMiterlimit: 10,
        }}
      />
      <path
        d="M64.76,377a117.35,117.35,0,0,1,11.51,44.08"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeMiterlimit: 10,
        }}
      />
      <path
        d="M44.76,346.4a138,138,0,0,1,20,30.6"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeMiterlimit: 10,
        }}
      />
      <path
        d="M38.46,339.74s1.21,1.1,3.19,3.21"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeMiterlimit: 10,
        }}
      />
      <path
        d="M101.26,381.32a137.61,137.61,0,0,0-18.88,37.47"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeMiterlimit: 10,
        }}
      />
      <path
        d="M114.66,365.92a109.65,109.65,0,0,0-13.4,15.4"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeMiterlimit: 10,
        }}
      />
      <path
        d="M129,355a60.51,60.51,0,0,0-10.2,7.23"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeMiterlimit: 10,
        }}
      />
      <path
        d="M100.77,347.4c-6.46,20.3-15.12,50.31-19.16,76.35"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeMiterlimit: 10,
        }}
      />
      <path
        d="M104.7,335.35c-1.15,3.43-2.49,7.49-3.93,12"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeMiterlimit: 10,
        }}
      />
      <path
        d="M108.72,323.7s-1.12,3.11-2.94,8.44"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeMiterlimit: 10,
        }}
      />
      <path
        d="M52.69,392.94c8.06,3.05,15.93,8.95,19.76,20.12"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeMiterlimit: 10,
        }}
      />
      <path
        d="M37.8,389.91a50.55,50.55,0,0,1,14.89,3"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeMiterlimit: 10,
        }}
      />
      <path
        d="M28.15,390.15s1.44-.21,3.8-.3"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeMiterlimit: 10,
        }}
      />
      <path
        d="M131.69,401.46c11.86-2,20.76-7.82,19.88-13s-11.19-7.72-23-5.71-20.76,7.82-19.89,13S119.84,403.46,131.69,401.46Z"
        style={{
          fill: "#6D8263",
          stroke: "#263238",
          strokeMiterlimit: 10,
        }}
      />
      <path
        d="M109.5,392.84c-8.15,3-16.15,8.93-20,20.22"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeMiterlimit: 10,
        }}
      />
      <path
        d="M125.38,389.85a51.62,51.62,0,0,0-15.88,3"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeMiterlimit: 10,
        }}
      />
      <path
        d="M133.78,390.15s-.94-.14-2.57-.24"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeMiterlimit: 10,
        }}
      />
      <path
        d="M109.33,448.75a56.62,56.62,0,0,0,5.5-24,49.55,49.55,0,0,0-2.2-14.71h-62a49.55,49.55,0,0,0-2.2,14.71,56.48,56.48,0,0,0,5.51,24Z"
        style={{
          fill: "#263238",
        }}
      />
      <path
        d="M49,416.88c-.18,1.13-.31,2.27-.41,3.43h66.05c-.1-1.16-.24-2.3-.42-3.43Z"
        style={{
          fill: "#7a7a7a",
        }}
      />
      <path
        d="M113.93,434.44c.21-1.14.39-2.28.53-3.43H48.77c.13,1.15.31,2.29.52,3.43Z"
        style={{
          fill: "#7a7a7a",
        }}
      />
      <path
        d="M56.41,424.9a2.68,2.68,0,1,1-2.67-2.68A2.68,2.68,0,0,1,56.41,424.9Z"
        style={{
          fill: "#8c8c8c",
        }}
      />
      <path
        d="M69.77,424.9a2.67,2.67,0,1,1-2.67-2.68A2.67,2.67,0,0,1,69.77,424.9Z"
        style={{
          fill: "#8c8c8c",
        }}
      />
      <path
        d="M83.14,424.9a2.68,2.68,0,1,1-2.67-2.68A2.68,2.68,0,0,1,83.14,424.9Z"
        style={{
          fill: "#8c8c8c",
        }}
      />
      <path
        d="M96.5,424.9a2.67,2.67,0,1,1-2.67-2.68A2.67,2.67,0,0,1,96.5,424.9Z"
        style={{
          fill: "#8c8c8c",
        }}
      />
      <path
        d="M109.87,424.9a2.68,2.68,0,1,1-2.67-2.68A2.68,2.68,0,0,1,109.87,424.9Z"
        style={{
          fill: "#8c8c8c",
        }}
      />
    </g>
    <g id="freepik--Page--inject-179">
      <rect
        x={234.16}
        y={84.46}
        width={234.28}
        height={331.28}
        style={{
          fill: "#263238",
        }}
      />
      <rect
        x={228.37}
        y={78.67}
        width={234.28}
        height={331.28}
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <rect
        x={238.24}
        y={111.55}
        width={212.91}
        height={60.01}
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <rect
        x={238.24}
        y={99.22}
        width={69.87}
        height={12.33}
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <rect
        x={381.27}
        y={99.22}
        width={69.87}
        height={12.33}
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={238.24}
        y1={131.28}
        x2={451.15}
        y2={131.28}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={238.24}
        y1={150.19}
        x2={451.15}
        y2={150.19}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <rect
        x={238.24}
        y={190.04}
        width={212.91}
        height={60.01}
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={238.24}
        y1={209.77}
        x2={451.15}
        y2={209.77}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={238.24}
        y1={228.68}
        x2={451.15}
        y2={228.68}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={241.71}
        y1={116.37}
        x2={267.6}
        y2={116.37}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={373.75}
        y1={116.37}
        x2={399.64}
        y2={116.37}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={241.71}
        y1={102.33}
        x2={267.6}
        y2={102.33}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={382.36}
        y1={102.33}
        x2={408.25}
        y2={102.33}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={241.71}
        y1={135.08}
        x2={267.6}
        y2={135.08}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={241.71}
        y1={155.66}
        x2={267.6}
        y2={155.66}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={321.67}
        y1={155.66}
        x2={347.55}
        y2={155.66}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={317.5}
        y1={100.15}
        x2={369.27}
        y2={100.15}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={317.5}
        y1={105.45}
        x2={369.27}
        y2={105.45}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={312.28}
        y1={166.85}
        x2={324.02}
        y2={166.85}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={326.95}
        y1={166.85}
        x2={338.69}
        y2={166.85}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={341.62}
        y1={166.85}
        x2={353.36}
        y2={166.85}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <rect
        x={238.24}
        y={262.66}
        width={212.91}
        height={60.01}
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M242.91,278.1s4-9.9,1.58-7.53-4.36,10.7,1.58,8.72,9.9-10.7,8.32-7.13-.79,6.33,4,3.56,5.54-2.77,5.94-1.19,1.58,1.19,5.94-.39,4,1.19,4,2.37,5.55.8,7.53,0,3.56-3.16,4-.39,4.35,2.77,4.35,2.77h10.69"
        style={{
          fill: "none",
          stroke: "#6D8263",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={238.24}
        y1={282.39}
        x2={451.15}
        y2={282.39}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={238.24}
        y1={301.3}
        x2={451.15}
        y2={301.3}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={241.71}
        y1={267.48}
        x2={267.6}
        y2={267.48}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={373.75}
        y1={267.48}
        x2={399.64}
        y2={267.48}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={241.71}
        y1={286.19}
        x2={267.6}
        y2={286.19}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={241.71}
        y1={306.77}
        x2={267.6}
        y2={306.77}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={321.67}
        y1={306.77}
        x2={347.55}
        y2={306.77}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={312.28}
        y1={317.96}
        x2={324.02}
        y2={317.96}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={326.95}
        y1={317.96}
        x2={338.69}
        y2={317.96}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={341.62}
        y1={317.96}
        x2={353.36}
        y2={317.96}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={243.33}
        y1={196.19}
        x2={304.21}
        y2={196.19}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={243.33}
        y1={215.99}
        x2={280.74}
        y2={215.99}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={337.95}
        y1={215.99}
        x2={375.36}
        y2={215.99}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={396.64}
        y1={240.94}
        x2={434.05}
        y2={240.94}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={388.57}
        y1={215.99}
        x2={425.98}
        y2={215.99}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <rect
        x={381.23}
        y={236.53}
        width={8.8}
        height={8.8}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={335.75}
        y1={240.94}
        x2={373.16}
        y2={240.94}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <rect
        x={320.35}
        y={236.53}
        width={8.8}
        height={8.8}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={274.87}
        y1={240.94}
        x2={312.28}
        y2={240.94}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <rect
        x={259.46}
        y={236.53}
        width={8.8}
        height={8.8}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={425.65}
        y1={334.09}
        x2={450.18}
        y2={334.09}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={328.29}
        y1={334.09}
        x2={422.49}
        y2={334.09}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={267.6}
        y1={334.09}
        x2={325.45}
        y2={334.09}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={239.66}
        y1={334.09}
        x2={265.38}
        y2={334.09}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={396.57}
        y1={339.78}
        x2={450.18}
        y2={339.78}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={294.15}
        y1={339.78}
        x2={394.04}
        y2={339.78}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={239.66}
        y1={339.78}
        x2={290.99}
        y2={339.78}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={410.48}
        y1={345.47}
        x2={450.18}
        y2={345.47}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={325.13}
        y1={345.47}
        x2={408.27}
        y2={345.47}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={276.45}
        y1={345.47}
        x2={320.7}
        y2={345.47}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={239.66}
        y1={345.47}
        x2={273.6}
        y2={345.47}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={432.29}
        y1={351.16}
        x2={450.18}
        y2={351.16}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={253.05}
        y1={351.16}
        x2={429.13}
        y2={351.16}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={239.66}
        y1={351.16}
        x2={250.53}
        y2={351.16}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={436.4}
        y1={356.85}
        x2={450.18}
        y2={356.85}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={392.46}
        y1={356.85}
        x2={433.56}
        y2={356.85}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={325.13}
        y1={356.85}
        x2={390.25}
        y2={356.85}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={262.22}
        y1={356.85}
        x2={322.6}
        y2={356.85}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={239.66}
        y1={356.85}
        x2={258.74}
        y2={356.85}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={425.34}
        y1={362.54}
        x2={450.18}
        y2={362.54}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={345.68}
        y1={362.54}
        x2={421.86}
        y2={362.54}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={294.15}
        y1={362.54}
        x2={341.57}
        y2={362.54}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={239.66}
        y1={362.54}
        x2={290.99}
        y2={362.54}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={388.98}
        y1={368.24}
        x2={450.18}
        y2={368.24}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={267.6}
        y1={368.24}
        x2={384.56}
        y2={368.24}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={239.66}
        y1={368.24}
        x2={264.12}
        y2={368.24}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={241.86}
        y1={385.44}
        x2={268.27}
        y2={385.44}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={372.43}
        y1={385.44}
        x2={398.84}
        y2={385.44}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={274.87}
        y1={385.44}
        x2={363.63}
        y2={385.44}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={406.17}
        y1={385.44}
        x2={449.45}
        y2={385.44}
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M245.16,207.31s4.08.94,5-3.77-2.83-2.2-2.83.31,1.26,5,6,1.26,3.45-3.14,6.28-.32.31,3.46,6,1.26,6-1.26,5.65.63-1.57.94,3.77-.94,7.85-3.46,7.22-1-2.83,3.14,1.25.32,6.6-11.93,3.14-5-4.71,6,.32,5,6.59-4.4,6.59-1.89-4.08,4.09,0,2.52,5.65-3.14,5.65-1.57-3.77,4.39,1.57,1.88,6.91-5.34,6.91-3.14-.95,1.57,0,2.2-.95-1.26,1.88-.32,1.57,2.83,5.65,1.26,3.77-3.77,6-1.57,0,5.34,6,2.51,7.53-1.25,9.42-.94a27.41,27.41,0,0,0,4.71.31c1.25,0,.94-1.25,4.08,0a12.49,12.49,0,0,0,6,1.26H355"
        style={{
          fill: "none",
          stroke: "#6D8263",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M374.18,207.62a43.47,43.47,0,0,0,4.39-2.2c2.83-1.57,10.05-6.9,10.36-3.45s-7.85,7.85-6.9,4.08,6.59-1.88,10.67-.31,5-.32,10.05-.32,4.39,1.57,6.9,2.2,1.57,0,6-1.88,1.25-11-1.57-4.71-3.77,8.79,2.82,5.65,4.71.63,5.65.63-.63.31,3.14-1.26-.94.63,1.89,1.26,4.39-2.52,6.9-3.46,2.83,1.89,2.83,1.89h2.51"
        style={{
          fill: "none",
          stroke: "#6D8263",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M243.27,147s1.57-.63,4.08-4.39-1.57-5-2.51-.94-3.14,8.79,3.77,5.33,4.39-10,2.2-5-1.57,10.05,5,6.28,7.22-6,8.16-4.08-2.51,2.51,3.14,2.82,6.59-1.57,9.1-2.51,3.77,0,3.77,0a7.52,7.52,0,0,0,2.2.32c1.25,0,2.82-1,3.45,0s-6.28,2.19,1.89.94,10-6.6,10.67-2.51-5.65,7.53-5.65,3.76,3.77-7.53,9.73-4.08,5.65,4.4,8.79,5,8.16-2.82,8.16-2.82-.31.31,1.57,1.25,1.26.95,4.71,0,.63-.31,5.34-.94,6.9-.31,5,1.26-7.22-.63-.31-1.88,7.84.94,7.84,1.88,1.89,1.25,3.46.63a23.43,23.43,0,0,1,4.71-.95"
        style={{
          fill: "none",
          stroke: "#6D8263",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M251.43,128.51a48.59,48.59,0,0,0,7.44-1.85c2.07-.73,4-1.69,4.81-2.86,2.19-3.14-4.4-2.2-8.48,1.89s2.51,4.39,11,1.57,8.16-10.05,2.51-4.71-3.45,6.59,5.34,4.71,19.77-4.09,16.32-1-4.39,1.57,1.57.32,9.73-4.08,8.79-1.89-3.45,5,1.26,2.83,4.08,0,4.08,0c8.47-.94,13.18-11.62,7.22-7.85s-6,8.79-.63,8.48,10.36-5.34,7.85-2.83-6.59,4.4,2.19,2.2,11.62-6.91,11-3.77-.94,2.83,2.2,2.83,8.79-4.4,6.91-1.26-2.83,3.45,0,2.83,6.9-2.83,8.16-2.83-2.51,3.45,1.25,3.14,11.62-5,11.62-5"
        style={{
          fill: "none",
          stroke: "#6D8263",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M355,123.49s7.85,5.33,9.73,5.33"
        style={{
          fill: "none",
          stroke: "#6D8263",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <polyline
        points="322.48 238.78 323.41 243.14 333.06 231.63"
        style={{
          fill: "none",
          stroke: "#6D8263",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
    </g>
    <g id="freepik--Character--inject-179">
      <path
        d="M215.77,428.7l7.86,7.66s17.94,6.65,18.75,7.86,0,4.64,0,4.64H201.06l1.09-16.46Z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M242.73,446.24H201.24l-.18,2.62h41.32A15.43,15.43,0,0,0,242.73,446.24Z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M130.87,297.21l5.67,67S132,404.56,132,408.56s-2,17-2,17l13.67,1.67,18.23-69,2.67-28,22.33,50.33,15.28,51.86,13.62-3.7-10.56-66.49-19.59-62.67-1.41-7.33-53.34.66Z"
        style={{
          fill: "#263238",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M130,425.56l-4,10.92s-7.45,8.66-6.85,10.28a3.34,3.34,0,0,0,2,2h18.54a2.38,2.38,0,0,0,1.81-2,25.51,25.51,0,0,0,.4-4.44l1.75-15.09Z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M141.49,446.76q.09-.39.15-.81H119.21a1.36,1.36,0,0,0-.09.81,3.34,3.34,0,0,0,2,2h18.54A2.38,2.38,0,0,0,141.49,446.76Z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M149.87,201.29s-17.5,1-22.75,4.5-30.75,24.5-30.75,24.5l1.31,21.84,28.19-20.34,4,70.5,55.75-2.75-1.25-39.25-.75-1.25s18,18.5,24.75,18,8.25-11.75,3.25-18.75-12.5-17-17.75-24.5-5.25-18.5-13-23.75-21.25-8.25-21.25-8.25Z"
        style={{
          fill: "#6D8263",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={184.37}
        y1={260.29}
        x2={183.28}
        y2={237.72}
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={186.85}
        y1={246.71}
        x2={187.49}
        y2={242.84}
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={184.78}
        y1={259.11}
        x2={186.39}
        y2={249.49}
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={161.49}
        y1={273.53}
        x2={164}
        y2={276.27}
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={134.49}
        y1={244.05}
        x2={159.91}
        y2={271.8}
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={143.62}
        y1={262.11}
        x2={153.46}
        y2={271.76}
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={138.7}
        y1={257.3}
        x2={141.53}
        y2={260.07}
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <polyline
        points="134.19 226.28 125.87 231.79 133.89 231.1"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M148.14,180.9a87.73,87.73,0,0,1,.9,11.52,82.29,82.29,0,0,1-.9,11.29s11.29,17.17,13.32,18.52,3.39-4.52,3.39-7,.23-9.71.23-9.71v-8.13Z"
        style={{
          fill: "#b0b0b0",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M165,206.63c0-.68,0-1.11,0-1.11v-8.13l-3.84-3.73-9.37-3.79Z"
        style={{
          fill: "#263238",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M175.69,158.31s2.71,8.81,2.94,12.42-1.81,6.33-1.81,7.46,3.16,5.64,3.16,7.23-3.84,3.61-3.84,3.61-1.58,8.36-5.64,11.07-13.33-3.84-16.94-7.23a21.74,21.74,0,0,1-6.33-10.16c-1.13-3.62.23-12,2.49-18.75a15.36,15.36,0,0,1,12.42-10.84C167.33,152.21,175,155.15,175.69,158.31Z"
        style={{
          fill: "#b0b0b0",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M172.3,179.66c0,1.06-.35,1.92-.79,1.92s-.79-.86-.79-1.92.36-1.92.79-1.92S172.3,178.6,172.3,179.66Z"
        style={{
          fill: "#263238",
        }}
      />
      <path
        d="M170,175.7s3.17-1.58,5,.46"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M171.85,192.42s-4.74-1.58-5-5"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M149,180.07s4.29.68,4.74-1.58-2.26-2.71.68-4.74,5-2,5.87-3.39-.36-3.54,1.22-7.15,3.48-2.68,8-2a20.45,20.45,0,0,1,7.49,2.6s2.78-5.88-.16-9.27-12.27-6.83-22.66-3.67-13.54,10.68-14.44,18.81S142,182.33,145,183.23,149,180.07,149,180.07Z"
        style={{
          fill: "#263238",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M151.3,179.54s-2.71-8.35-5-4.06-1.13,7.9,1.13,9.26a2.07,2.07,0,0,0,3.16-1.13"
        style={{
          fill: "#b0b0b0",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M201.22,265.08c2.88-5.29,15.63-20.86,15.63-20.86l8.31,4s-6.29,22.92-9.31,26.19-6.34,4.38-9.87,1.86"
        style={{
          fill: "#b0b0b0",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M206.16,276.12a7.9,7.9,0,0,0,9.87-1.86c.91-1,2.12-3.77,3.36-7.16a13,13,0,0,1-14.6-7.32,34.69,34.69,0,0,0-3.87,6.17c-.1.31.73,4.14.68,4.42"
        style={{
          fill: "#6D8263",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M300.72,279.21a1.44,1.44,0,0,1-.57-.11l-10.67-4.43a1.5,1.5,0,1,1,1.15-2.77l10.67,4.43a1.5,1.5,0,0,1-.58,2.88Z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M267.41,271.45,30.25,165a7.51,7.51,0,0,1-3.77-9.92h0a7.5,7.5,0,0,1,9.91-3.77L273.55,257.76Z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M62.44,163l-26-11.69A7.5,7.5,0,0,0,30.25,165l25.4,11.48Z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <polygon
        points="273.55 257.76 297.29 274.02 295.81 277.18 267.41 271.45 273.55 257.76"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M56.14,160.19l-19.75-8.86A7.5,7.5,0,0,0,30.25,165l18.92,8.49Z"
        style={{
          fill: "#6D8263",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M80.12,175.79s-2,10.75-.5,12.75,9.75,9.5,9.75,9.5-3.25,43.75-2.5,47.75,9.25,7,12,6.25,4.75-3.75,7.25-9.25-8.75-44-8.75-45.75-5.25-15.25-5.25-15.25,4.25-3,5-4-3-.25-3.75-.25a41.65,41.65,0,0,1-7.25-1.5C85.12,175.54,80.12,175.79,80.12,175.79Z"
        style={{
          fill: "#b0b0b0",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M92.22,177.48s-3.54.89-3.41,1.77.13,6.45.13,6.45"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M86.79,176.6s-3-.13-3,1.52v6.95"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <line
        x1={80.08}
        y1={176.47}
        x2={80.59}
        y2={185.07}
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M98.87,252c2.75-.75,4.75-3.75,7.25-9.25.95-2.07-.07-8.84-1.69-16.56a18.75,18.75,0,0,1-17.05,2c-.49,8.59-.8,16.06-.51,17.61C87.62,249.79,96.12,252.79,98.87,252Z"
        style={{
          fill: "#6D8263",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M216.76,232.24a5.53,5.53,0,0,1,3.71-1.3c2,.19,2.41,3.16,2.22,5.75s-3,3.16-3.34,1.49-.74-4.27-.74-4.27Z"
        style={{
          fill: "#b0b0b0",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M222.32,232.06a2.94,2.94,0,0,1,3.53,1.67c1.11,2.41-.19,5.56-1.49,5.75s-1.67-2.79-1.67-2.79Z"
        style={{
          fill: "#b0b0b0",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M225.85,233.73a1.8,1.8,0,0,1,2.59,1.29c.75,2.23,1.49,5-.18,5s-2.23-3-2.23-3Z"
        style={{
          fill: "#b0b0b0",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
      <path
        d="M228.44,235s2.42-.18,3,1.3,1.67,4.27-.37,4.27c-.55,0-1.85-2.6-1.85-2.6Z"
        style={{
          fill: "#b0b0b0",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }}
      />
    </g>
  </svg>
)
export default RegistrationIllustration