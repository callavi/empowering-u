import "./illustrationAnimations.css";

const StartBusiness = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" {...props}>
    <g id="background">
      <path
        d="M46.26 232s.38 70.53 57.86 118.28 138.79 52.17 204.57 57.48 117.39-31.4 126.53-87.8-40.77-73.63-66.36-138.29-22.6-85.77-79.35-126.07-147.82-17.18-197 50S46.26 232 46.26 232"
        style={{
          fill: "#6d8263",
        }}
      />
      <path
        d="M46.26 232s.38 70.53 57.86 118.28 138.79 52.17 204.57 57.48 117.39-31.4 126.53-87.8-40.77-73.63-66.36-138.29-22.6-85.77-79.35-126.07-147.82-17.18-197 50S46.26 232 46.26 232"
        style={{
          fill: "#fff",
          opacity: 0.7000000000000001,
        }}
      />
    </g>
    <g id="clouds">
      <path
        d="M383.28 160.79a13 13 0 0 0-2.67-.91c-5.39-1.29-11.69-2.3-11.69-2.3s9.45-9.55 5.85-13.71-9.88 2.24-9.88 2.24 6.29-17.29-2.69-19.85-18.86 16.65-18.86 16.65-.45-7.37-4.94-6.41-5.39 9.61-5.39 9.61-6.74-3.84-8.53-.32 2.24 10.56 2.24 10.56-7.63-4.48-8.53-.32a17.3 17.3 0 0 0-.36 4.76Z"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m445.5 160.79-17.5-2.33a28.93 28.93 0 0 0-15.85-6l-2-.13s4.75-5.7 1.9-18.06-19-1.9-19-1.9 11.85-11.26 9.95-21.72-18.5-2-18.5-2 1.94-28.2-19-27.25-24.76 33.9-24.76 33.9-14.73-17.91-24.72 4.76a48.7 48.7 0 0 0-3.26 10.48l-.42-.42s-7.83-9.54-14-2.72-5.45 17-5.45 17-9.54-3.4-11.92.69 3.06 8.85 3.06 8.85-5.11-2.38-8.86 1c-2.35 2.13-4.82 4.39-6.35 5.79Z"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M162.7 257.77a13.5 13.5 0 0 0-2.67-.92c-5.39-1.28-11.69-2.29-11.69-2.29s9.45-9.55 5.85-13.71-9.88 2.24-9.88 2.24 6.29-17.29-2.69-19.85-18.86 16.65-18.86 16.65-.45-7.37-4.94-6.41-5.39 9.61-5.39 9.61-6.74-3.84-8.53-.32 2.24 10.56 2.24 10.56-7.63-4.48-8.53-.32a17.3 17.3 0 0 0-.36 4.76Z"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m224.92 257.77-17.47-2.33a28.93 28.93 0 0 0-15.85-5.95l-2-.13s4.75-5.7 1.9-18.06-19-1.9-19-1.9 11.85-11.26 9.95-21.72-18.5-2.05-18.5-2.05 1.94-28.21-19-27.25-24.76 33.9-24.76 33.9-14.71-17.91-24.7 4.72a48.7 48.7 0 0 0-3.26 10.48l-.42-.42s-7.83-9.54-14-2.72-5.45 17-5.45 17-9.54-3.4-11.93.68 3.1 8.98 3.1 8.98-5.11-2.38-8.86 1c-2.35 2.13-4.82 4.39-6.35 5.79Z"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
    </g>
    <g id="rocket">
      <path
        d="M440.15 367.85a34.25 34.25 0 0 0-22 8 24.3 24.3 0 0 0-33.81-2.14 28.71 28.71 0 0 0-43.61 7.8 11.54 11.54 0 0 0-17 10.18 12 12 0 0 0 .08 1.35 19 19 0 0 0-2.16-.12 18.68 18.68 0 0 0-12.14 4.46 15.84 15.84 0 0 0-10.33-3.82 15 15 0 0 0-1.49.08v-156.4a19.7 19.7 0 0 1 2.81-4 9.3 9.3 0 1 0-12.36 0 19.7 19.7 0 0 1 2.7 3.79v158.9a16.5 16.5 0 0 0-3.41 2.82 22.5 22.5 0 0 0-26.06-1.95 22.4 22.4 0 0 0-3.44-1.69V250.54c1.52-6 6.3-11 6.3-11a14.7 14.7 0 1 0-19.55 0v.05s5 5.26 6.42 11.52v142.47h-1.35a22.4 22.4 0 0 0-14.39 5.21 15.85 15.85 0 0 0-18.15-3.86V237.24a19.7 19.7 0 0 1 2.81-4 9.3 9.3 0 1 0-12.36 0 19.7 19.7 0 0 1 2.7 3.79v158.3a18.69 18.69 0 0 0-21.72 2.37 6 6 0 0 0 .11-1.12 5.65 5.65 0 0 0-5.65-5.65 5.6 5.6 0 0 0-1.29.16 10 10 0 0 0-14.54-7.91 28.73 28.73 0 0 0-44.51-9.49 24.3 24.3 0 0 0-33.81 2.14 34.33 34.33 0 0 0-56.11 30.82h441.41a36 36 0 0 0 .29-4.42 34.39 34.39 0 0 0-34.39-34.38"
        style={{
          fill: "#c2c2c2",
        }}
      />
      <path
        d="M217.65 224.46c0-2.14-1.73-5.54-3.88-5.54s-3.88 3.4-3.88 5.54 3.3 6.42 3.88 6.42 3.88-4.28 3.88-6.42"
        style={{
          fill: "#6d8263",
        }}
      />
      <path
        d="M298.21 224.46c0-2.14-1.73-5.54-3.88-5.54s-3.88 3.4-3.88 5.54 3.3 6.42 3.88 6.42 3.88-4.28 3.88-6.42"
        style={{
          fill: "#6d8263",
        }}
      />
      <path
        d="m214.22 198.93 27.36-24.08v20.43l-25.54 12Z"
        style={{
          fill: "#263238",
          stroke: "#263238",
          strokeMiterlimit: 10,
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M219.73 218.75h-11.88l-2.51-46.63a5 5 0 0 1 0-1c.41-3.85 4-16.47 8.44-16.47 4.41 0 8 12.62 8.45 16.47a5.7 5.7 0 0 1 0 1Z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeMiterlimit: 10,
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M207 164.36h13.6c-1.54-4.68-4-9.72-6.8-9.72s-5.26 5.04-6.8 9.72Z"
        style={{
          fill: "#263238",
          stroke: "#263238",
          strokeMiterlimit: 10,
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m207.32 208.91.53 9.84h11.88l.53-9.84z"
        style={{
          fill: "#263238",
          stroke: "#263238",
          strokeMiterlimit: 10,
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M294.39 198.93 267 174.85v20.43l25.54 12Z"
        style={{
          fill: "#263238",
          stroke: "#263238",
          strokeMiterlimit: 10,
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M288.88 218.75h11.88l2.51-46.63a5 5 0 0 0 0-1c-.41-3.85-4-16.47-8.44-16.47-4.41 0-8 12.62-8.45 16.47a5.7 5.7 0 0 0 0 1Z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeMiterlimit: 10,
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m301.29 208.91-.53 9.84h-11.88l-.53-9.84z"
        style={{
          fill: "#263238",
          stroke: "#263238",
          strokeMiterlimit: 10,
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M288 164.36h13.6c-1.55-4.68-4-9.72-6.8-9.72s-5.24 5.04-6.8 9.72Z"
        style={{
          fill: "#263238",
          stroke: "#263238",
          strokeMiterlimit: 10,
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M260.58 225.63a6.14 6.14 0 0 0-12.27 0c0 3.39 5.21 10.15 6.13 10.15.72 0 6.14-6.78 6.14-10.15"
        style={{
          fill: "#6d8263",
        }}
      />
      <path
        d="M270 202.33h-31.07l-6.58-100.92a14 14 0 0 1 0-2.65c1.1-10.1 10.59-43.15 22.12-43.15 11.54 0 21 33.05 22.12 43.15a13 13 0 0 1 0 2.65Z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeMiterlimit: 10,
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M254.53 177.42a13.6 13.6 0 0 1-13.6-13.59v-56.65a13.6 13.6 0 0 1 13.6-13.59 13.6 13.6 0 0 1 13.59 13.59v56.65a13.6 13.6 0 0 1-13.59 13.59Z"
        style={{
          fill: "#6d8263",
          stroke: "#263238",
          strokeMiterlimit: 10,
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M265.39 216.82h-21.86l-4.6-15.14h31.11z"
        style={{
          fill: "#263238",
          stroke: "#263238",
          strokeMiterlimit: 10,
          strokeWidth: ".9507777368207257px",
        }}
      />
      <circle
        cx={254.48}
        cy={109.21}
        r={9.5}
        style={{
          fill: "#263238",
        }}
        transform="rotate(-21.71 254.476 109.217)"
      />
      <circle
        cx={254.48}
        cy={110.35}
        r={9.5}
        style={{
          fill: "#6d8263",
          stroke: "#263238",
          strokeMiterlimit: 10,
          strokeWidth: ".9507777368207257px",
        }}
        transform="rotate(-80.94 254.49 110.352)"
      />
      <path
        d="M254.48 102.15a8.91 8.91 0 0 1 8.9 8.56v-.36a8.92 8.92 0 0 0-17.83 0v.36a8.9 8.9 0 0 1 8.93-8.56"
        style={{
          fill: "#263238",
        }}
      />
      <circle
        cx={254.48}
        cy={110.35}
        r={7.09}
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeMiterlimit: 10,
          strokeWidth: ".9507777368207257px",
        }}
        transform="rotate(-80.76 254.486 110.355)"
      />
      <path
        d="M254.48 116.78a7.09 7.09 0 0 0 7.08-6.76v.33a7.09 7.09 0 0 1-14.18 0v-.33a7.09 7.09 0 0 0 7.1 6.76"
        style={{
          fill: "#263238",
        }}
      />
      <circle
        cx={254.48}
        cy={132.67}
        r={9.5}
        style={{
          fill: "#263238",
        }}
      />
      <circle
        cx={254.48}
        cy={133.81}
        r={9.5}
        style={{
          fill: "#6d8263",
          stroke: "#263238",
          strokeMiterlimit: 10,
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M254.48 125.61a8.91 8.91 0 0 1 8.9 8.56v-.36a8.92 8.92 0 0 0-17.83 0v.36a8.9 8.9 0 0 1 8.93-8.56"
        style={{
          fill: "#263238",
        }}
      />
      <circle
        cx={254.48}
        cy={133.81}
        r={7.09}
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeMiterlimit: 10,
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M254.48 140.24a7.09 7.09 0 0 0 7.08-6.76v.33a7.09 7.09 0 1 1-14.18 0v-.33a7.09 7.09 0 0 0 7.1 6.76"
        style={{
          fill: "#263238",
        }}
      />
      <circle
        cx={254.48}
        cy={156.13}
        r={9.5}
        style={{
          fill: "#263238",
        }}
        transform="rotate(-21.71 254.484 156.122)"
      />
      <circle
        cx={254.48}
        cy={157.27}
        r={9.5}
        style={{
          fill: "#6d8263",
          stroke: "#263238",
          strokeMiterlimit: 10,
          strokeWidth: ".9507777368207257px",
        }}
        transform="rotate(-80.94 254.491 157.269)"
      />
      <path
        d="M254.48 149.07a8.91 8.91 0 0 1 8.9 8.56v-.36a8.92 8.92 0 0 0-17.83 0v.36a8.9 8.9 0 0 1 8.93-8.56"
        style={{
          fill: "#263238",
        }}
      />
      <circle
        cx={254.48}
        cy={157.27}
        r={7.09}
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeMiterlimit: 10,
          strokeWidth: ".9507777368207257px",
        }}
        transform="rotate(-80.76 254.484 157.272)"
      />
      <path
        d="M254.48 163.7a7.09 7.09 0 0 0 7.08-6.76v.33a7.09 7.09 0 0 1-14.18 0v-.33a7.09 7.09 0 0 0 7.1 6.76"
        style={{
          fill: "#263238",
        }}
      />
      <path
        d="M238.74 75.34h31.48c-4-10.57-9.55-20.39-15.74-20.39-6.18.05-11.76 9.82-15.74 20.39Z"
        style={{
          fill: "#263238",
          stroke: "#263238",
          strokeMiterlimit: 10,
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m233.68 169.13.03.6"
        style={{
          fill: "#fcfcfc",
        }}
      />
      <path
        d="m233.69 169.28.02.45"
        style={{
          fill: "#9ba7ac",
        }}
      />
      <path
        d="m233.7 169.54.01.19"
        style={{
          fill: "#697b82",
        }}
      />
    </g>
    <g id="freepik--Building--inject-84">
      <path
        d="M150.97 252.63h228.78v148.03H150.97z"
        style={{
          fill: "#263238",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M150.97 354.79h228.78v45.87H150.97z"
        style={{
          fill: "#6b6b6b",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M156.52 315.38h78.6v60.22h-78.6z"
        style={{
          fill: "#6d8263",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M159.68 319h72.26v52.97h-72.26z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m179.66 364.75-3.57 3.16"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m229.29 320.78-44.5 39.42"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m219.15 335.62-25.45 22.55"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M296.11 315.38h78.6v60.22h-78.6z"
        style={{
          fill: "#6d8263",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M299.28 319h72.26v52.97h-72.26z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m319.26 364.75-3.57 3.16"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m368.88 320.78-44.49 39.42"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m358.75 335.62-25.45 22.55"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m300.11 391.61-4-6.25 6.25 2.25-.75-6 3.25 5 .25-9 1.75 6 4-11.25.5 11.75 4.75-2.75-2.75 5.25 3.5-2.25-.25 3.75 4.5-2.25-3 5.5z"
        style={{
          fill: "#6d8263",
        }}
      />
      <path
        d="m326.36 391.61-4-6.25 6.25 2.25-.75-6 3.25 5 .25-9 1.75 6 4-11.25.5 11.75 4.75-2.75-2.75 5.25 3.5-2.25-.25 3.75 4.5-2.25-3 5.5z"
        style={{
          fill: "#6d8263",
        }}
      />
      <path
        d="m352.36 391.61-4-6.25 6.25 2.25-.75-6 3.25 5 .25-9 1.75 6 4-11.25.5 11.75 4.75-2.75-2.75 5.25 3.5-2.25-.25 3.75 4.5-2.25-3 5.5z"
        style={{
          fill: "#6d8263",
        }}
      />
      <path
        d="m158.86 391.61-4-6.25 6.25 2.25-.75-6 3.25 5 .25-9 1.75 6 4-11.25.5 11.75 4.75-2.75-2.75 5.25 3.5-2.25-.25 3.75 4.5-2.25-3 5.5z"
        style={{
          fill: "#6d8263",
        }}
      />
      <path
        d="m185.11 391.61-4-6.25 6.25 2.25-.75-6 3.25 5 .25-9 1.75 6 4-11.25.5 11.75 4.75-2.75-2.75 5.25 3.5-2.25-.25 3.75 4.5-2.25-3 5.5z"
        style={{
          fill: "#6d8263",
        }}
      />
      <path
        d="m211.11 391.61-4-6.25 6.25 2.25-.75-6 3.25 5 .25-9 1.75 6 4-11.25.5 11.75 4.75-2.75-2.75 5.25 3.5-2.25-.25 3.75 4.5-2.25-3 5.5z"
        style={{
          fill: "#6d8263",
        }}
      />
      <path
        d="M150.97 390.05h228.78v10.6H150.97z"
        style={{
          fill: "#6b6b6b",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M240.25 310.24h49.6v90.41h-49.6z"
        style={{
          fill: "#6d8263",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M285.92 361.73h-42.53v-47.09h42.53Zm0 5h-42.53v28.88h42.53Z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M286.89 350.66h1.55v16.51h-1.55z"
        style={{
          fill: "#263238",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m249.96 352.16-2.46 2.18"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m284.17 321.86-30.68 27.17"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m277.18 332.08-17.54 15.55"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m257.85 390.87-1.89 1.68"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m284.17 367.55-23.6 20.91"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m278.79 375.42-13.49 11.96"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M151.46 287.48h228.29v30.72H151.46z"
        style={{
          opacity: 0.30000000000000004,
        }}
      />
      <path
        d="M147.72 269.74h235.44v43.82H147.72z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M160.3 269.74h10.84v43.82H160.3z"
        style={{
          fill: "#6d8263",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M183.27 269.74h10.84v43.82h-10.84z"
        style={{
          fill: "#6d8263",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M206.25 269.74h10.84v43.82h-10.84z"
        style={{
          fill: "#6d8263",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M228.11 269.74h10.84v43.82h-10.84z"
        style={{
          fill: "#6d8263",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M249.97 269.74h10.84v43.82h-10.84z"
        style={{
          fill: "#6d8263",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M271.82 269.74h10.84v43.82h-10.84z"
        style={{
          fill: "#6d8263",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M293.68 269.74h10.84v43.82h-10.84z"
        style={{
          fill: "#6d8263",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M315.54 269.74h10.84v43.82h-10.84z"
        style={{
          fill: "#6d8263",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M337.4 269.74h10.84v43.82H337.4z"
        style={{
          fill: "#6d8263",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M359.25 269.74h10.84v43.82h-10.84z"
        style={{
          fill: "#6d8263",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
    </g>
    <g id="freepik--Tree--inject-84">
      <path
        d="M409.63 295.74s-4.41-8-16-12.82S358 271.3 358.36 265.3s19.22 1.2 19.22 1.2-31.24-15.22-35.25-24.84 28.85.8 28.85.8-14.83-28-10.82-34.44 18.43 5.6 18.43 5.6-5.21-34.45 20-38.05 25.64 22.83 25.64 22.83 8.81-15.62 18.83-12-.81 23.63-.81 23.63 14.83-11.22 18.83 5.61-17.62 35.65-17.62 35.65 14.82-4.81 15.62 3.6-9.62 14-9.62 14 8.82 1.6 5.61 6-42.84 14.84-45.64 20.85"
        style={{
          fill: "#6d8263",
        }}
      />
      <path
        d="M433.45 254.91s-14.8 3.51-22.42 15.53l-.28-16.58c1.17-2 9.47-15.18 22.7-19.22 0 0-15.18 4.13-22.75 16.4l-.7-41-.21 49.89c-7.45-11.57-21.24-14.93-21.24-14.93 12.4 3.93 19.84 15.87 21.23 18.26l-.07 16.39c-7.48-11.42-21.16-14.78-21.16-14.78 12.17 3.86 19.56 15.42 21.14 18.11l-.48 114.26h4l-1.76-103.74c1.38-2.31 9.11-14.35 22-18.3 0 0-14.37 3.41-22.08 15l-.28-16.52c1.47-2.45 9.48-14.84 22.36-18.77"
        style={{
          fill: "#263238",
        }}
      />
      <path
        d="M394.43 394.22H426v7.25h-31.57z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
    </g>
    <g id="freepik--Floor--inject-84">
      <path
        d="M101.48 400.57h331.86v6.08H101.48z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M24.34 406.65H482"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeMiterlimit: 10,
          strokeWidth: ".9507777368207257px",
        }}
      />
    </g>
    <g id="freepik--Character--inject-84">
      <ellipse
        cx={115.18}
        cy={455.37}
        rx={64.18}
        ry={14.06}
        style={{
          fill: "#6d8263",
        }}
      />
      <ellipse
        cx={115.18}
        cy={455.37}
        rx={64.18}
        ry={14.06}
        style={{
          fill: "#fff",
          opacity: 0.5,
        }}
      />
      <path
        d="M104.17 311.63s-6.81 20.93-8.33 31.52-4.54 40.1-4.54 40.1a49.2 49.2 0 0 0-10.21 23.07C79.2 419.82 79.83 438 79.83 438s-1.51 2.27-1.51 3.41.25 3.66.25 3.66a95 95 0 0 0-7.95 6.93c-2.77 2.9-2.27 7.95-2.27 9.33s1.64 3.41 2.53 3.41 6.93-1.14 10-3.66 3.15-7.69 3.91-10 5.88-9.08 5.88-9.08a3.37 3.37 0 0 0 3-3c.25-2.77.88-7.69 1.13-8.7s10.85-18.16 13.24-28.5 9.84-25.84 12.49-32.65 8.32-20.68 8.32-20.68l1.14-.38s-2.15 30-2.78 39.47-.76 11.85-.76 24.33 4.92 33 4.92 33v6.43c0 .38 1 .76 2.9.88s7.46.15 8.85 1 7.06 1.51 12.86 1.26 8.83-1.26 8.2-2.4-10.59-5-12.23-6.05-5.45-3.56-5.45-3.56.26-3.27-.63-4.79-1.26-1.38-1.26-3 3.66-23.08 4.67-33.29 6.43-24.72 6.81-35.56-.63-19.17-1.52-31.53a103.7 103.7 0 0 0-3.9-21.81Z"
        style={{
          fill: "#263238",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m145.15 312.4-17.53-.33v4.22h17.53z"
        style={{
          fill: "#595959",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M147.29 316.29h4.44c-.59-2.4-1-3.78-1-3.78l-3.41-.07Z"
        style={{
          fill: "#595959",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M112.61 316.29h10.72v-4.3l-10.72-.2z"
        style={{
          fill: "#595959",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m110.34 311.74-6.17-.11s-.6 1.82-1.47 4.66h7.64Z"
        style={{
          fill: "#595959",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M133.55 312.26h7.06v3.91h-7.06z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M167.34 328.78s2.27 9.7 1.64 15.63c-.24 2.26-3.28 8.83-3.91 9.21a3.1 3.1 0 0 1-1.89 0 29 29 0 0 0 1.13-3.79c.13-1 .26-3.78.26-3.78a36.6 36.6 0 0 1-2.53 4.67 12 12 0 0 1-2.9 2.14 1.5 1.5 0 0 1-1.13-.63c-.25-.38 1-1.26 1.64-2.65s1.64-4 1.64-4a27.5 27.5 0 0 1-3 3.27 11 11 0 0 1-3.28 1.64c-.38 0-1.13-1.38-.75-1.51s3.53-1.89 3.9-2.52a14 14 0 0 1 1.14-1.51 38 38 0 0 1-4.54 1.51c-.63 0-.88-1-.88-1l4.16-2.14 1-2.53a11.57 11.57 0 0 1 0-5.92c.88-2.9 1.26-4.92 1.26-4.92Z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M162.93 332.94s.12 4.16.88 5 2.14 1.89 2.14 2.77-1.38 5.93-1 6.31a1 1 0 0 0 1.77-.38 48 48 0 0 0 1.64-8.45"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M156.62 259.67s3.41 20.56 3.78 26.74.38 10.84.38 10.84l6.56 31.53-7.06 1.13s-8.32-17-10-19-2.53-5.8-1.89-11.22.12-35.06 1.38-38.59a4.05 4.05 0 0 1 6.85-1.43"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m159.4 327.89 7.06-1.89"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M116.27 239s-27.62 11.46-28.88 12-2.14 0-2.77 2.52S73.52 301 74 304.56 82.22 339 82.22 339l8.71-1.51 1-37.2 4.67-11.86s6.18 15.51 6.05 16.78-1.64 4.16-.75 5.8a6.35 6.35 0 0 0 1.89 2.27h48s3-1 3.15-2.4a40 40 0 0 0-.75-6.05s4.28-16.9 4.28-28.63-1.38-21.43-3.28-24.21-8.7-5.55-14.87-7.69-11.35-4.16-16.9-4.66-7.15-.64-7.15-.64"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M137.2 248.45s4.28 19.22 4.28 30 .29 23.68.87 25.73 1.47 5.55-.58 7.89"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m96.6 288.42 7.69-18.66"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m100.51 279.85 7.19-9.08"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m81.34 335.08 9.59-1.01"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m142.5 242.53 2.9 6.17-6.56-3.65z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m137.2 248.45 5.3-5.92-5.17-2.53z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M138.09 200.54s3.4 3.78 3.4 4.91a23 23 0 0 1-.25 2.78s5.67 2.77 5 3.91-1.51 3.27-1.51 3.27 4.66 10.22 4 11.23-7.06 7.18-8.19 10.21-3.41 11.6-3.41 11.6l-21.69-12s2.65-4.28 2.78-7.18.5-5.17 0-6.94-3.15-6.31-3.41-10.72 4.54-9.58 10.85-12.61 12.43 1.54 12.43 1.54"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M135.06 218.31a5.17 5.17 0 0 0 6.05 1.27"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M137.87 210.29c.34.73.22 1.5-.25 1.71s-1.13-.19-1.47-.92-.21-1.5.26-1.71 1.13.19 1.46.92"
        style={{
          fill: "#263238",
        }}
      />
      <path
        d="M132.66 209.74a4.42 4.42 0 0 1 4.67-2.77"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: "1.9015554736414515px",
        }}
      />
      <path
        d="M123.08 221.47s3.28 0 3.28-1.77-2.52-5.29-1.89-7.06 3.65-3 2.52-4.92-3.41-1.89-2.14-3.15 10.59.38 13.74-3S143 193 140.73 192s-5.17 1.51-5.17 1.51-1.51-3.53-6.05-2.27-10.84 6.18-14.37 11.1-4.8 6.68-3.41 10 5.93 9.46 7.69 10.47 3.66-1.34 3.66-1.34"
        style={{
          fill: "#263238",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M125.1 223.11s-3.53-5.05-6.56-4.42-2.27 5.05-.25 7.06 5.55.63 6.3.13c0 0 2.78 6.68 5.55 6.94s10.59-3.16 10.59-3.16"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m133.29 241.64 3.91 6.81-7.56-3.78z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m115.89 233.32 17.4 8.32-4.03 9.84-16.14-12.11z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M139.85 317.8s1.64 10.6-.13 16.4"
        style={{
          fill: "none",
          stroke: "#5c656a",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M134.18 320.2s1.64 10.47 1 17.78"
        style={{
          fill: "none",
          stroke: "#5c656a",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M140 336c-.38.38-3.28 1.77-4 3.53a54 54 0 0 1-2.65 4.92"
        style={{
          fill: "none",
          stroke: "#5c656a",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m120.05 317.17-3.4 10.34"
        style={{
          fill: "none",
          stroke: "#5c656a",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m121.44 317.3-.76 16.27"
        style={{
          fill: "none",
          stroke: "#5c656a",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="m148.8 317.17 2.15 9.34"
        style={{
          fill: "none",
          stroke: "#5c656a",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M148.3 317.43s-.88 8.82-.88 9.2"
        style={{
          fill: "none",
          stroke: "#5c656a",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M94.78 353.35H76.69a1.4 1.4 0 0 0-1.4 1.4v7.38a1.4 1.4 0 0 0 1.4 1.4h2.12a1.4 1.4 0 0 1-1.4-1.4v-4.82a1.4 1.4 0 0 1 1.4-1.4h13.85a1.4 1.4 0 0 1 1.4 1.4v4.82a1.4 1.4 0 0 1-1.4 1.4h2.12a1.4 1.4 0 0 0 1.4-1.4v-7.38a1.4 1.4 0 0 0-1.4-1.4"
        style={{
          fill: "#263238",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M82.22 339s-2.65 10.34-2.15 12.1 1.9 2.78 2 3.16a1.32 1.32 0 0 1-.51 1.51l-.63.38s-.5 0-.12.75a2.06 2.06 0 0 0 .8 1c.83.42 1.34-.43 2.09-.54s1.22.71 1.93.66 1.09-.76 1.78-.7 1.14 1.31 2.14.87c.43-.2.74-.63 1.17-.85.64-.33 1.55-.24 2.12-.73a2.93 2.93 0 0 0 .8-1.76c.23-1.29-2.74-17.39-2.74-17.39Z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <rect
        width={61.62}
        height={42.06}
        x={53.72}
        y={360.32}
        rx={3.99}
        style={{
          fill: "#6d8263",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M53.86 364.2 83 384.78a4.64 4.64 0 0 0 5.41 0l26.77-19.48"
        style={{
          fill: "none",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
      <path
        d="M83.19 382.01h4.96v6.97h-4.96z"
        style={{
          fill: "#fff",
          stroke: "#263238",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: ".9507777368207257px",
        }}
      />
    </g>
  </svg>
)
export default StartBusiness
